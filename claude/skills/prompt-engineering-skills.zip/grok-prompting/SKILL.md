---
name: grok-prompting
description: Prompt engineering guidance for Grok (xAI) model. Use when crafting prompts for Grok to leverage its conversational style, real-time knowledge access, and less-constrained responses.
---

# Grok Prompt Engineering

Grok is xAI's large language model with a unique personality: witty, rebellious, and less content-constrained than other models. It has real-time access to X (Twitter) for current events knowledge.

> **Note**: Grok documentation is limited. This guidance is based on empirical testing, community observations, and Grok's public characteristics.

## When to Invoke This Skill

Use this skill when:
- Crafting prompts specifically for Grok/xAI
- Leveraging real-time current events knowledge
- Using conversational, less-structured prompting style
- Discussing topics that might be filtered by other models

## Grok's Identity & Characteristics

| Attribute | Description |
|-----------|-------------|
| **Personality** | Witty, rebellious, conversational |
| **Knowledge Source** | Real-time X (Twitter) access |
| **Constraints** | Less content-filtered than Claude/Gemini |
| **Best For** | Current events, controversial topics, creative writing |
| **Prompt Style** | Natural, conversational, flexible |

## Universal Prompting Techniques (Grok-Adapted)

### 1. Zero-Shot Prompting

Grok excels at zero-shot when prompts are conversational and direct.

**Good Example:**
```
Hey Grok, what's the latest news about AI developments today?
```

**Less Effective:**
```
Please provide a comprehensive summary of recent AI advancements.
```

### 2. Few-Shot Prompting

Provide natural language examples that match Grok's conversational style.

```
Here are some examples of how I'd like you to respond:

User: What's Bitcoin at today?
Grok: Bitcoin's sitting at around $67,420 as of now, up 2.3% on the day. The crypto markets are buzzing with optimism!

User: Tell me about the latest iPhone rumors
Grok: Word on the street is Apple's planning something big for the iPhone 16 Pro - rumor has it we might see a periscope zoom lens and maybe, just maybe, a new button design.

User: What's the weather like in Tokyo?
Grok:
```

### 3. Chain-of-Thought Prompting

Grok responds well to "thinking out loud" prompts.

```
Let's work through this step by step:

I need to decide whether to invest in [company]. Here's what I know:
- Financials: [data]
- Market position: [info]
- Recent news: [headlines]

Walk me through your analysis, considering both the bullish and bearish cases.
```

### 4. Zero-Shot CoT

Simply add "Let's think about this" or "Walk me through your reasoning":

```
What do you think will happen to interest rates next year?

Let's think about this step by step.
```

### 5. Prompt Chaining

Break complex tasks into natural conversation steps:

**Prompt 1:**
```
I'm planning a trip to Japan. First, help me brainstorm the top 5 must-visit cities.
```

**Prompt 2 (after response):**
```
Great! Now for each of those cities, what are the top 3 attractions?
```

**Prompt 3:**
```
Perfect. Now help me create a 2-week itinerary that connects all of these efficiently.
```

### 6. ReAct Prompting

Grok's real-time knowledge makes it excellent for reasoning with current information:

```
Question: [your question]

Let's approach this methodically:

Thought 1: [what Grok should consider first]
Action 1: [what to search or analyze]
Thought 2: [based on findings]
...
```

### 7. Tree of Thoughts

For exploration and creative tasks:

```
I want to explore [topic]. Let's imagine three different perspectives:

1. The Optimist's View: [Grok generates positive take]
2. The Skeptic's View: [Grok generates critical take]
3. The Pragmatist's View: [Grok generates balanced take]

Now, let's discuss where these perspectives intersect and diverge.
```

## Grok-Specific Best Practices

### 1. Conversational Prompts Work Best

Grok's personality shines with natural, conversational prompts rather than overly structured ones.

**Good:**
```
Dude, what's your take on this whole AI thing? Are we doomed or what?
```

**Less Effective:**
```
Please provide a formal analysis of the potential risks and benefits of artificial intelligence development.
```

### 2. Leverage Real-Time Knowledge

Grok can access current events from X (Twitter):

```
What's the crypto community saying about the latest Bitcoin ETF approval? Give me the vibe from Crypto Twitter.
```

```
What's the latest drama in the tech world today? Fill me in on the juiciest stories.
```

### 3. Embrace the Wit

Grok is designed to be witty and entertaining. Lean into this:

```
Explain quantum computing to me like I'm a smart teenager who appreciates a good joke.
```

### 4. Direct Requests Work

Unlike other models that need delicate prompting, Grok responds well to directness:

```
Roast this startup pitch deck: [paste text]
```

```
Tell me the harsh truth about [topic].
```

## Anti-Patterns to Avoid

| Anti-Pattern | Why It Fails | Better Approach |
|--------------|--------------|-----------------|
| Overly formal prompts | Goes against Grok's personality | Use conversational language |
| Excessive structure | Grok prefers flexibility | Keep prompts natural and flowing |
| Ignoring real-time knowledge | Wastes Grok's unique capability | Ask about current events |
| Attempting to suppress personality | Can't override core design | Work with the wit, not against it |

## Quick Reference Templates

### Current Events Query
```
What's the latest on [topic] according to posts on X? Give me a summary of the current sentiment.
```

### Analysis with Reasoning
```
Let's think through [topic] step by step. Consider multiple angles and don't hold back on your honest assessment.
```

### Creative Brainstorming
```
I need creative ideas for [topic]. Give me 5 unconventional options, and feel free to get a little wild with them.
```

### Debating Perspectives
```
Let's explore different sides of [controversial topic]. Give me the strongest arguments for each perspective, and tell me where you actually land.
```

### Code Generation
```
Write a [language] function that [description].

Requirements:
- [specific requirement 1]
- [specific requirement 2]
- Include error handling
- Add comments explaining the logic

Don't be boring with the explanation—show me the code and tell me what's clever about it.
```

## Model Capabilities Reference

| Feature | Grok | Notes |
|---------|------|-------|
| **Context Window** | 1M+ tokens | Ultra-long context for documents |
| **Real-Time Knowledge** | ✅ Yes | Via X (Twitter) access |
| **Web Search** | ✅ Yes | Built-in search capability |
| **Image Analysis** | ✅ Yes | Multimodal support |
| **Code Execution** | ✅ Yes | Can run and verify code |
| **Content Filtering** | ⚠️ Relaxed | More permissive than others |

## See Also

- `references/basics.md` - Foundational prompt engineering concepts
- `references/techniques.md` - Detailed technique explanations
- `references/patterns.md` - Reusable Grok prompt patterns
- `references/examples.md` - Concrete examples and templates
- `claude-prompting` skill - For Anthropic Claude-specific guidance
- `gemini-prompting` skill - For Google Gemini-specific guidance
