# Grok Prompt Examples

Real-world examples of effective Grok prompts across different use cases.

---

## Example 1: Current Events Analysis

**Prompt:**
```
What's the latest drama in the AI world today? Fill me in on the juiciest stories and what people are actually saying about them on X.
```

**Why It Works:**
- Conversational tone matches Grok's personality
- Leverages real-time X access
- Asks for "juicy" stories (plays to Grok's style)
- Seeks authentic social sentiment

---

## Example 2: Investment Analysis

**Prompt:**
```
I'm thinking about buying NVIDIA at these levels. Let's think through this:

The Bull Case: They're basically the only game in town for AI chips, demand is insane, and they're pricing it aggressively.

The Bear Case: Valuation is stretched, competition is coming (AMD, Intel, custom chips), and AI spending might plateau.

Walk me through your actual take. Don't give me the "it depends" answer - where do you land if you had to pick a side?
```

**Why It Works:**
- Provides context (shows you've done homework)
- Sets up the framework (bull/bear)
- Asks for a definitive stance
- Conversational but structured

---

## Example 3: Honest Tech Feedback

**Prompt:**
```
Here's my startup idea: AI-powered todo app that uses GPT-4 to prioritize your tasks automatically.

Roast it. Be brutal but fair - what's actually interesting vs what's delusional?
```

**Why It Works:**
- Clear, concise idea description
- Asks for brutality (Grok will comply)
- Seeks fair assessment (not just negativity)
- "Roast" trigger fits Grok's personality

---

## Example 4: Learning Complex Topics

**Prompt:**
```
Explain how transformers actually work. Not the "it's like attention" analogy - I want to understand what's really happening under the hood.

Assume I'm a decent programmer but haven't really dug into ML internals.
```

**Why It Works:**
- Specific about what you DON'T want (superficial analogies)
- Clear about your background (sets appropriate level)
- Asks for "under the hood" explanation
- Direct and specific

---

## Example 5: Code Review

**Prompt:**
```
I wrote this Python script to scrape some data. It works but I feel like it's janky.

[paste code]

Give it to me straight:
1. What's actually good about this?
2. What's going to break in production?
3. What would you rewrite entirely?

Don't hold back - I can take it.
```

**Why It Works:**
- Shows awareness something is off
- Asks for specific feedback categories
- Signals willingness to hear criticism
- Conversational ("I can take it")

---

## Example 6: Decision Support

**Prompt:**
```
Job offer dilemma:

Offer A: $180k at Series B startup, 0.5% equity, fully remote, founders seem solid
Offer B: $220k at Big Tech, standard RSU package, hybrid in SF, known commodity

I'm leaning toward the startup but my friends think I'm crazy. What am I not considering here? Give me the perspective I might be missing.
```

**Why It Works:**
- Clear comparison with relevant details
- Acknowledges your bias (leaning startup)
- Asks what you're missing (meta-cognition)
- Seeks perspective beyond your echo chamber

---

## Example 7: Crypto Sentiment

**Prompt:**
```
Solana's up 15% today. What's actually driving this? Is this real momentum or just another pump? Give me the vibe from Crypto Twitter and separate the signal from the noise.
```

**Why It Works:**
- Specific situation (Solana +15%)
- Asks about drivers (not just price)
- Distinguishes signal vs noise (sophisticated)
- Leverages real-time sentiment analysis

---

## Example 8: Technical Debate

**Prompt:**
```
Settle this debate for me:

React dev: "Use React, it's the industry standard, ecosystem is unbeatable"

Vue dev: "Vue is simpler, faster, and you don't need 50 libraries to do anything"

Svelte dev: "Both are dinosaurs, Svelte is the future"

I'm starting a new side project. Which one should I actually choose and why? Don't just say "it depends" - give me a real recommendation.
```

**Why It Works:**
- Presents the competing views
- Contextualizes (side project)
- Asks for a real recommendation
- Acknowledges the cop-out answer

---

## Example 9: Exploring Controversial Topics

**Prompt:**
```
Let's have an honest conversation about AI art.

Some say it's theft, others say it's transformative, others say it's just another tool.

Give me the strongest version of each argument, then tell me where you actually land on this. And be honest - do you think your training was any different?
```

**Why It Works:**
- Acknowledges controversy upfront
- Asks for strongest versions (steel-manning)
- Asks for Grok's actual opinion
- Direct question about its own training (meta)

---

## Example 10: Travel Planning

**Prompt:**
```
I'm going to Tokyo for the first time. Everyone says "go to Shibuya Crossing" but that sounds touristy as hell.

If you had 3 days in Tokyo and wanted to actually experience the city (not just check off Instagram spots), where would you go? Give me the local's perspective.
```

**Why It Works:**
- Acknowledges typical advice (Shibuya)
- Signals desire for authenticity
- Asks for "local's perspective"
- Clear timeframe (3 days)

---

## Example 11: Career Advice

**Prompt:**
```
I'm a 28-year-old software dev at a Big Tech company. Comp is great but I'm bored and feel like I'm not learning anything.

Options:
1. Stay and coast (build passive income stuff on side)
2. Join a late-stage startup (more exciting, still stable-ish)
3. Join an early-stage startup (high risk, high learning)

Walk me through your thinking on each. What would you actually do in my position?
```

**Why It Works:**
- Clear context (age, role, situation)
- Specific options to evaluate
- Asks for reasoning, not just conclusion
- "What would you do" (personalizes it)

---

## Example 12: Exploring Ideas

**Prompt:**
```
I have an idea: a social network where you can only post during working hours (9-5 local time). The thesis is that it would eliminate doomscrolling and make content more thoughtful.

Am I onto something or is this stupid? Be honest - would people actually use this?
```

**Why It Works:**
- Clear, concise idea
- Asks for validation (on something or stupid)
- Questions viability (would people use it)
- Open to harsh feedback

---

## Example 13: Research Synthesis

**Prompt:**
```
I've been reading about longevity and keep seeing conflicting advice:

- Some say: fasting, cold exposure, intense exercise
- Others say: calorie sufficiency, stress reduction, moderate activity
- Others say: it's mostly genetics, don't overthink it

What's actually supported by evidence? Help me cut through the noise here.
```

**Why It Works:**
- Shows you've done research
- Identifies the contradiction
- Asks for evidence-based answer
- "Cut through the noise" (clear goal)

---

## Example 14: Writing Feedback

**Prompt:**
```
I wrote this essay about [topic]. I think it's decent but it feels... safe? Like I'm not really saying anything new.

[paste essay]

Read this and tell me:
1. What parts are actually interesting?
2. Where am I being generic?
3. What would make this actually provocative?

Don't compliment my writing - tell me what's missing.
```

**Why It Works:**
- Self-aware (knows it feels safe)
- Asks specific questions
- "Don't compliment" (wants real feedback)
- Asks for provocative elements (clear goal)

---

## Example 15: Understanding Hype

**Prompt:**
```
Everyone's talking about [new tech trend]. Is this actually going to matter or is it another Web3 situation (lots of hype, not much substance)?

Compare it to [previous trend] that actually delivered vs [previous trend] that didn't. Where does this fall?
```

**Why It Works:**
- Contextualizes (compares to previous trends)
- Asks for binary assessment (matter or not)
- Uses historical analogies
- Seeks pattern recognition

---

## Prompt Analysis Table

| Example | Key Techniques | Why Effective |
|---------|---------------|---------------|
| 1. Current Events | Real-time knowledge, conversational tone | Matches Grok's personality |
| 2. Investment | Bull/bear framing, definitive stance | Provides structure, demands opinion |
| 3. Startup Roast | Brutal feedback request | Plays to Grok's directness |
| 4. Transformers | Specific about what not to do | Clear constraints, appropriate level |
| 5. Code Review | Self-awareness, specific categories | Signals openness to critique |
| 6. Job Offer | Context, bias acknowledgment, meta-question | Seeks outside perspective |
| 7. Crypto | Signal vs noise, sentiment analysis | Leverages real-time X data |
| 8. Framework Debate | Steel-manning, demand recommendation | Avoids "it depends" |
| 9. AI Art | Steel-manning, meta question | Handles controversy well |
| 10. Tokyo | Anti-tourist framing, local perspective | Seeks authenticity |
| 11. Career | Clear options, personalization | Specific, relatable |
| 12. Social Network | Concise idea, validation question | Quick, direct |
| 13. Longevity | Research synthesis, noise reduction | Shows homework done |
| 14. Essay | Self-aware, critical feedback | Wants growth, not praise |
| 15. Hype Cycle | Historical comparison | Pattern-based reasoning |
