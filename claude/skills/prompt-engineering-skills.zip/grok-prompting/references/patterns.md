# Grok Prompt Patterns

Reusable prompt patterns optimized for Grok's conversational style and capabilities.

---

## Current Events & Real-Time Knowledge

### News Summarizer
```
What's the latest on [topic] based on what people are discussing on X? Give me:
1. The key headlines
2. The general sentiment (bullish/bearish/neutral)
3. The most interesting hot takes
```

### Crypto/Finance Pulse
```
What's the crypto community saying about [coin/token] right now? Give me the vibe from Crypto Twitter and any notable influencers chiming in.
```

### Tech Rumor Mill
```
What are the latest rumors and leaks about [company/product]? Fill me in on what the tech community is buzzing about.
```

### Breaking News Analysis
```
There's news about [event]. What's the real story behind the headlines? What are people who actually know the industry saying?
```

---

## Analysis & Opinion

### Honest Assessment
```
Give me your honest, unfiltered take on [topic]. Don't give me the safe PR answer - tell me what you actually think and where the potential problems are.
```

### Bull vs Bear Case
```
Let's explore [investment/decision/topic] from both sides:

The Bull Case: [generate optimistic view]
The Bear Case: [generate skeptical view]
The Reality: [your balanced assessment]

Where do you land and why?
```

### Devil's Advocate
```
Everyone says [popular opinion]. Play devil's advocate and give me the strongest arguments against this view.
```

### Hot Take Generator
```
Give me 5 hot takes on [topic] that might be controversial but actually have merit. Don't hold back.
```

---

## Decision Support

### Pros and Cons
```
I'm trying to decide [decision]. Walk me through:
- The best arguments for doing it
- The best arguments against it
- What most people miss
- Your recommendation

Be direct and don't sugarcoat it.
```

### Trade-off Analysis
```
Compare [Option A] vs [Option B] for [purpose]. Focus on:
- What you gain with each
- What you sacrifice with each
- Which trade-offs are worth it
- Your pick and why
```

### Reality Check
```
Here's my plan: [describe plan]

Give me a reality check. What am I not considering? What could go wrong? Am I being overly optimistic or pessimistic?
```

---

## Creative & Ideation

### Brainstorming Session
```
I need ideas for [challenge]. Give me 10 options ranging from practical to wild. Don't filter anything - let's see what we come up with.
```

### Startup Pitch Roast
```
Roast this startup idea: [paste idea]

Be brutal but fair. What's actually good vs what's delusional?
```

### Counterintuitive Thinking
```
Everyone assumes [common belief]. What if the opposite is true? Walk me through a scenario where that makes sense.
```

### Unconventional Solutions
```
I have [problem]. The typical solutions are [list them].

Now give me 3 unconventional approaches that most people wouldn't consider.
```

---

## Technical & Coding

### Code Review
```
Review this code and tell me:
1. What actually works well
2. What's problematic or could break
3. What's over-engineered
4. Your honest assessment of the overall quality

[paste code]

Don't hold back - I want the real feedback.
```

### Architecture Debate
```
[Person A] says [approach A] is better. [Person B] says [approach B] is better.

Weigh in on this debate. What are they both missing? Which approach actually makes sense for [specific use case]?
```

### Tech Stack Decision
```
I'm building [project] and considering [tech options].

Give me your honest recommendation. Don't just repeat the conventional wisdom - tell me what you'd actually choose and why.
```

---

## Learning & Explanations

### Complex Topic Explained
```
Explain [complex topic] to me like I'm [specific persona: smart teenager, non-technical CEO, curious grandparent].

Keep it interesting but actually accurate. No dumbing down - just clear explanations.
```

### Myth Busting
```
Everyone believes [myth] about [topic]. What's actually true? Bust this myth with facts and explain why the misconception is so common.
```

### Deep Dive
```
I want to really understand [topic]. Give me a deep dive that covers:
- What it is
- Why it matters
- How it actually works
- Common misconceptions
- What experts argue about

Make it comprehensive but keep it engaging.
```

---

## Entertainment & Personality

### Roast Mode
```
Roast [target: myself/my code/my ideas]. Be funny but actually insightful - the kind of roast that makes you think.
```

### Snarky Summary
```
Give me a snarky but accurate summary of [topic/article/event]. Don't hold back on the commentary.
```

### Conspiracy Theory Generator (Satire)
```
Generate the most entertaining (but clearly absurd) conspiracy theory about [mundane topic]. Lean into the absurdity.
```

### Alternate History
```
What if [historical event] had gone differently? Walk me through a plausible alternate timeline and how it would change today.
```

---

## Research & Investigation

### Connect the Dots
```
Here are some pieces of information:
[info 1]
[info 2]
[info 3]

Connect the dots. What's the bigger picture here that people are missing?
```

### Follow the Money
```
[Company/person] is doing [action]. What's really going on here? Follow the incentives and tell me what's actually motivating this.
```

### Pattern Recognition
```
I've noticed [pattern] in [domain]. Am I onto something or is this confirmation bias? Help me analyze whether this pattern is real.
```

---

## Comparative Analysis

### Framework Comparison
```
Compare [Framework A] vs [Framework B] for [use case]. Don't give me the generic comparison - tell me:
- When each actually makes sense
- What the fans of each get wrong
- What the haters miss
- Your honest recommendation
```

### Product Showdown
```
[Product A] or [Product B] for [specific purpose]? Settle this debate for me once and for all.
```

### Era Comparison
```
Compare [current state of things] vs [past era]. What's actually better now? What was better then? No rose-colored glasses - real talk.
```

---

## Meta-Prompts

### Prompt Improver
```
Here's my prompt for Grok: [paste prompt]

Critique it and give me a better version that would get more useful results.
```

### Question Refiner
```
I want to ask about [topic] but I'm not sure how to phrase it. Help me craft the question that would get me the best answer.
```

### Missing Angle
```
I've been thinking about [topic] from [perspective]. What am I missing? What other angles should I consider?
```

---

## Pattern Selection Guide

| Goal | Pattern | Why |
|------|---------|-----|
| Get current news | News Summarizer | Real-time X access |
| Honest feedback | Honest Assessment | Grok's directness |
| Explore options | Bull vs Bear Case | Natural contrarian |
| Generate ideas | Brainstorming Session | Creative potential |
| Learn deeply | Deep Dive | Knowledge breadth |
| Make decisions | Reality Check | Pragmatic insights |
| Be entertained | Roast Mode | Witty personality |
| Understand trends | Connect the Dots | Pattern recognition |
